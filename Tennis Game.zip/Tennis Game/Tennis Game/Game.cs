﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tennis_Game
{
    class Game
    {
        private int[] points = new int[2];
        private string server;
        private string receiver;

        public Game(string server, string receiver)
        {
            this.server = server;
            this.receiver = receiver;
        }

//Use this property to get the current score of the game
        public string Score
        {
            get
            {
                if (points[0] >= 3 && points[1] >= 3 && Math.Abs(points[0] - points[1]) < 2)
                    if (points[0] == points[1])
                        return "Deuce";
                    else if (points[0] > points[1])
                        return "Advantage " + server;
                    else
                        return "Advantage " + receiver;

                if (points[0] < 4 && points[1] < 4)
                    return CalculateScore(points[0]) + "-" + CalculateScore(points[1]);

                if (points[0] >= 4)
                    return CalculateScore(points[0]) + " " + server;

                return CalculateScore(points[1]) + " " + receiver;
            }
        }

        //use this method to score points to a player, by passing the player name
        internal void PointTo(string scoringPlayer)
        {
            if (scoringPlayer == server)
                points[0]++;
            else
                points[1]++;
        }

        static string CalculateScore(int points)
        {
            switch (points)
            {
                case 3:
                    return "Forty";
                case 2:
                    return "Thirty";
                case 1:
                    return "Fifteen";
                case 0:
                    return "Love";
                default:
                    return "Game";
            }
        }
    }
}
