﻿using System;

namespace Tennis_Game
{
    class Program
    {
        static void Main(string[] args)
        {

            //sampl data for set1
            Game game1 = new Game("Ndy Ezeocha", "Andy Murray");
            game1.PointTo("Ndy Ezeocha");
            game1.PointTo("Ndy Ezeocha");
            game1.PointTo("Andy Murray");
            game1.PointTo("Ndy Ezeocha");
            Console.WriteLine("Score for Set 1:- " + game1.Score);

            //sample data for set2
            Game game2 = new Game("Ndy Ezeocha", "Andy Murray");
            game2.PointTo("Ndy Ezeocha");
            game2.PointTo("Andy Murray");
            game2.PointTo("Ndy Ezeocha");
            game2.PointTo("Andy Murray");
            game2.PointTo("Ndy Ezeocha");
            game2.PointTo("Andy Murray");
            game2.PointTo("Andy Murray");
            Console.WriteLine("Score for Set 2:- " + game2.Score);

            //sample data for set3
            Game game3 = new Game("Ndy Ezeocha", "Andy Murray");
            game3.PointTo("Ndy Ezeocha");
            game3.PointTo("Ndy Ezeocha");
            game3.PointTo("Ndy Ezeocha");
            game3.PointTo("Andy Murray");
            game3.PointTo("Andy Murray");
            game3.PointTo("Andy Murray");
            game3.PointTo("Andy Murray");
            game3.PointTo("Andy Murray");
            Console.WriteLine("Score for Set 3:- " + game3.Score);

            Console.ReadLine();
        }
    }
}
